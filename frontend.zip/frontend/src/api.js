export const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL || '/recommend'

export async function fetchRecommendation(payload) {
  const res = await fetch(API_BASE_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      prompt: '',
      interests: payload.interests,
      strengths: payload.strengths,
      ambitions: payload.ambitions,
    }),
  })

  if (!res.ok) {
    throw new Error(`Request failed with status ${res.status}`)
  }

  const data = await res.json()
  return data.recommendation
}
