function ListCard({ title, items, accent }) {
  return (
    <div className="listcard">
      <h3 className={`listcard__title listcard__title--${accent}`}>{title}</h3>
      <ol className="listcard__items">
        {items.map((item, i) => (
          <li key={`${title}-${i}`}>
            <span className="listcard__num">{String(i + 1).padStart(2, '0')}</span>
            <span>{item}</span>
          </li>
        ))}
      </ol>
    </div>
  )
}

export default function RoadmapResult({ result }) {
  const roadmap = result.roadmap
  const isPlainText = typeof roadmap === 'string'
  const top = !isPlainText ? roadmap.top_tracks || [] : []
  const bestScore = top.length ? top[0].score : 0

  if (!isPlainText && roadmap.recommended === false) {
    return (
      <div className="roadmap roadmap--empty">
        <h2>Insufficient Signals</h2>
        <p>
          Select at least one interest, strength or ambition to generate a roadmap.
        </p>
      </div>
    )
  }

  if (isPlainText) {
    return (
      <div className="roadmap">
        <header className="roadmap__head">
          <div>
            <p className="roadmap__eyebrow">MODEL-GENERATED ROADMAP</p>
            <h2 className="roadmap__primary">{result.source}</h2>
          </div>
          <span className="roadmap__source">source: {result.source}</span>
        </header>
        <pre className="roadmap__raw">{roadmap}</pre>
      </div>
    )
  }

  return (
    <div className="roadmap">
      <header className="roadmap__head">
        <div>
          <p className="roadmap__eyebrow">RECOMMENDED ACADEMIC TRACK</p>
          <h2 className="roadmap__primary">{roadmap.primary_track}</h2>
          <p className="roadmap__summary">{roadmap.primary_summary}</p>
        </div>
        <span className="roadmap__source">source: {result.source}</span>
      </header>

      <section className="roadmap__grid">
        <ListCard title="Core Courses" items={roadmap.core_courses} accent="cyan" />
        <ListCard
          title="Freshman Starter Projects"
          items={roadmap.starter_projects}
          accent="amber"
        />
        <ListCard title="Career Paths" items={roadmap.career_paths} accent="green" />
      </section>

      {top.length > 1 && (
        <section className="scores">
          <h3 className="scores__title">Track Match Strength</h3>
          <div className="scores__list">
            {top.map((track) => (
              <div className="score" key={track.id}>
                <div className="score__row">
                  <span className="score__name">{track.name}</span>
                  <span className="score__value">{track.score} pts</span>
                </div>
                <div className="score__track">
                  <div
                    className={`score__fill score__fill--${track.id === top[0].id ? 'best' : 'other'}`}
                    style={{ width: `${bestScore ? (track.score / bestScore) * 100 : 0}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {roadmap.alternative_tracks?.length > 0 && (
        <section className="alternatives">
          <h3 className="alternatives__title">Alternative Tracks</h3>
          <div className="alternatives__grid">
            {roadmap.alternative_tracks.map((track) => (
              <div className="altcard" key={track.name}>
                <h4>{track.name}</h4>
                <p>{track.summary}</p>
                <span className="altcard__tag">{track.career_paths.slice(0, 3).join(' · ')}</span>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  )
}
