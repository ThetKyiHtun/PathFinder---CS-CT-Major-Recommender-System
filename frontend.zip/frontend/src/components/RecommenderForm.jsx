import { useState } from 'react'

const OPTIONS = {
  interests: [
    'AI',
    'Machine Learning',
    'Web Development',
    'Mobile Development',
    'Cybersecurity',
    'Networking',
    'Cloud Computing',
    'DevOps',
    'Data Science',
    'Game Development',
    'UI/UX Design',
    'Systems / Linux',
  ],
  strengths: [
    'Mathematics',
    'Logic',
    'Programming',
    'Systems Thinking',
    'Design',
    'Communication',
    'Statistics',
    'Creativity',
  ],
  ambitions: [
    'Technical Architect',
    'Security Engineer',
    'Network Engineer',
    'AI Researcher',
    'Data Scientist',
    'Full-Stack Developer',
    'DevOps Engineer',
    'Cloud Architect',
    'Game Developer',
    'UI/UX Designer',
  ],
}

const isCustom = (key, value) => key === 'ambitions' && !OPTIONS.ambitions.includes(value)

const SECTIONS = [
  { key: 'interests', label: 'Primary Interests', hint: 'What topics pull you in?' },
  { key: 'strengths', label: 'Core Strengths', hint: 'Where do you shine?' },
  { key: 'ambitions', label: 'Ambitions & Goals', hint: 'Where do you want to land?' },
]

const EMPTY = { interests: [], strengths: [], ambitions: [] }

export default function RecommenderForm({ onSubmit, loading }) {
  const [selection, setSelection] = useState(EMPTY)
  const [custom, setCustom] = useState('')

  const toggle = (key, value) => {
    setSelection((prev) => {
      const current = prev[key]
      const next = current.includes(value)
        ? current.filter((v) => v !== value)
        : [...current, value]
      return { ...prev, [key]: next }
    })
  }

  const addCustom = () => {
    const value = custom.trim()
    if (!value) return
    setSelection((prev) => ({
      ...prev,
      ambitions: prev.ambitions.includes(value)
        ? prev.ambitions
        : [...prev.ambitions, value],
    }))
    setCustom('')
  }

  const submit = () => {
    if (!selection.interests.length && !selection.strengths.length && !selection.ambitions.length) {
      return
    }
    onSubmit({ ...selection })
  }

  return (
    <form
      className="form"
      onSubmit={(e) => {
        e.preventDefault()
        submit()
      }}
    >
      <div className="form__head">
        <div>
          <h2>Student Profile</h2>
          <p>Select all that apply in each field.</p>
        </div>
        <span className="form__steps">3 FIELDS · 30+ OPTIONS</span>
      </div>

      {SECTIONS.map((section) => (
        <fieldset className="field" key={section.key}>
          <legend className="field__legend">
            <span className="field__label">{section.label}</span>
            <span className="field__hint">{section.hint}</span>
          </legend>
          <div className="chips">
            {OPTIONS[section.key].map((option) => {
              const active = selection[section.key].includes(option)
              return (
                <button
                  type="button"
                  key={option}
                  className={`chip${active ? ' chip--active' : ''}`}
                  aria-pressed={active}
                  onClick={() => toggle(section.key, option)}
                >
                  <span className="chip__tick">{active ? '✓' : '+'}</span>
                  {option}
                </button>
              )
            })}
            {selection[section.key]
              .filter((value) => isCustom(section.key, value))
              .map((value) => (
                <button
                  type="button"
                  key={value}
                  className="chip chip--active chip--custom"
                  aria-pressed="true"
                  onClick={() => toggle(section.key, value)}
                >
                  <span className="chip__tick">✓</span>
                  {value}
                </button>
              ))}
          </div>
        </fieldset>
      ))}

      <div className="field field--custom">
        <label className="field__label" htmlFor="custom-ambition">
          Custom Ambition
        </label>
        <div className="custom-row">
          <input
            id="custom-ambition"
            type="text"
            value={custom}
            placeholder="e.g. Quantum Computing Researcher"
            onChange={(e) => setCustom(e.target.value)}
          />
          <button type="button" className="btn btn--ghost" onClick={addCustom}>
            Add
          </button>
        </div>
      </div>

      <div className="form__foot">
        <p className="form__status">
          {selection.interests.length +
            selection.strengths.length +
            selection.ambitions.length}{' '}
          signals selected
        </p>
        <button
          type="submit"
          className="btn btn--primary"
          disabled={loading}
        >
          {loading ? 'Transmitting…' : 'Generate Roadmap'}
        </button>
      </div>
    </form>
  )
}
