import { useState } from 'react'
import RecommenderForm from './components/RecommenderForm.jsx'
import RoadmapResult from './components/RoadmapResult.jsx'
import { fetchRecommendation } from './api.js'

const initialForm = {
  interests: [],
  strengths: [],
  ambitions: [],
}

export default function App() {
  const [form, setForm] = useState(initialForm)
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const handleSubmit = async (values) => {
    setForm(values)
    setLoading(true)
    setError(null)
    setResult(null)
    try {
      const recommendation = await fetchRecommendation(values)
      setResult(recommendation)
    } catch (err) {
      setError(err.message || 'Something went wrong while contacting the API.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="app">
      <header className="topbar">
        <div className="topbar__mark" aria-hidden="true">
          <span className="topbar__logo">⌖</span>
          <span className="topbar__name">PathFinder</span>
        </div>
        <div className="topbar__meta">
          <span className="badge">CS &amp; CT</span>
          <span className="badge badge--outline">Serverless</span>
          <span className="badge badge--outline">POST /recommend</span>
        </div>
      </header>

      <section className="hero">
        <p className="hero__eyebrow">MAJOR RECOMMENDER SYSTEM · BUILD V1.0</p>
        <h1 className="hero__title">
          Chart your course from day one.
        </h1>
        <p className="hero__subtitle">
          Tell us what excites you, where you excel, and where you want to go.
          PathFinder drafts an academic roadmap of tracks, core courses and
          freshman starter projects — powered by a serverless pipeline.
        </p>
      </section>

      <main className="main">
        <RecommenderForm onSubmit={handleSubmit} loading={loading} />

        <section className="results">
          {loading && (
            <div className="scanline" role="status" aria-live="polite">
              <div className="scanline__bar" />
              <p>Generating roadmap from the compute layer…</p>
            </div>
          )}

          {error && (
            <div className="error" role="alert">
              <h2>Signal lost</h2>
              <p>{error}</p>
              <p className="error__hint">
                Make sure the API is deployed, or set <code>VITE_API_BASE_URL</code> in{' '}
                <code>frontend/.env</code>.
              </p>
            </div>
          )}

          {!loading && !error && !result && (
            <div className="placeholder">
              <div className="placeholder__grid" aria-hidden="true" />
              <p>Submit your profile to generate a career roadmap.</p>
            </div>
          )}

          {!loading && !error && result && <RoadmapResult result={result} />}
        </section>
      </main>

      <footer className="footer">
        <span>PathFinder · CS &amp; CT Major Recommender System</span>
        <span>API Gateway → AWS Lambda · Python 3.12 · x86_64</span>
      </footer>
    </div>
  )
}
